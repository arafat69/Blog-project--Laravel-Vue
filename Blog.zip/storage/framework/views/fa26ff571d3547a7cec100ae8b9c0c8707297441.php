<?php echo $__env->make('fontend.master.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<fontend-master></fontend-master>

<?php echo $__env->make('fontend.master.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH F:\Xampp\htdocs\blog\resources\views/fontend/master/master.blade.php ENDPATH**/ ?>