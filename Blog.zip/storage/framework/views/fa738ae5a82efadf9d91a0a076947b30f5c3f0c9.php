</div>

<footer>
    <div class="footer clearfix mb-0 text-muted">
        <div class="float-start">
            <p>2020 &copy; Voler</p>
        </div>
        <div class="float-end">
            <p>Crafted with <span class='text-danger'><i data-feather="heart"></i></span> by <a
                    href="#">Ahmad Saugi</a></p>
        </div>
    </div>
</footer>
</div>
</div>
<script src="<?php echo e(asset('backend/assets/js/feather-icons/feather.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/assets/vendors/perfect-scrollbar/perfect-scrollbar.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/assets/js/app.js')); ?>"></script>
<script src="<?php echo e(asset('backend/assets/js/pages/dashboard.js')); ?>"></script>

<script src="<?php echo e(asset('backend/assets/js/main.js')); ?>"></script>
</body>

</html>
<?php /**PATH F:\Xampp\htdocs\blog\resources\views/layouts/backend/footer.blade.php ENDPATH**/ ?>