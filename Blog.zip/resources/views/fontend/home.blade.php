@include('fontend.master.header')

<fontend-master></fontend-master>

@include('fontend.master.footer')
