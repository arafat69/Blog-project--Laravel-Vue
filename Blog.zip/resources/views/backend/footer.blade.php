</div>

</div>
</div>
<script src="{{ asset('js/app.js') }}"></script>
<script src="{{ asset('backend/assets/js/feather-icons/feather.min.js') }}"></script>
<script src="{{ asset('backend/assets/vendors/perfect-scrollbar/perfect-scrollbar.min.js') }}"></script>
<script src="{{ asset('backend/assets/js/app.js') }}"></script>
<script src="{{ asset('backend/assets/js/main.js') }}"></script>
<script>
</script>
</body>

</html>
