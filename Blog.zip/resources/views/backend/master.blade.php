@include('backend.sidebar')

@include('backend.header')

 {{-- @yield('content') --}}

 <admin-master></admin-master>

@include('backend.footer')
